package com.xuecheng.test.rabbitmq;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/*生产者*/
public class Producer01 {
    //队列常量
    private static final String QUEUE="Helloword";
    public static void main(String[] args) {
        //连接工程
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("127.0.0.1");
        connectionFactory.setPort(5672);
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        //设置虚拟机,一个MQ的服务可以设置多个虚拟机,而每个虚拟机就相当于独立的MQ
        connectionFactory.setVirtualHost("/");
        //和MQ建立连接
        Connection connection = null;
        Channel channel = null;
        try {
             connection = connectionFactory.newConnection();
             //创建会话通道,生产者和MQ所有的通信都是在Channel中完成
             channel = connection.createChannel();
            /*
            * 参数1 队列名称,参数2 是否持久话 ,参数3 是否独占连接,如果设置为true 可用于临时队列 exclusive
            * 参数4 autoDelete 自动删除
            * 参数5 qrgurents 参数,比如说存货时间
            * */
            channel.queueDeclare(QUEUE,true,false,false,null);
            //发送消息
            /*
              1,exchange 交换机(使用默认的设置为空串) 2,routingkey 路由key 如果使用默认交换机,routingkey设置为队列的名称
              3,prosp,消息的属性  4,消息内容
            * */
            //定义一个消息内容
            String massge="Hello word wangyang";
            channel.basicPublish("",QUEUE,null,massge.getBytes());
            System.out.println("send to sq"+massge);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            //先关闭通道
            try {
                channel.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

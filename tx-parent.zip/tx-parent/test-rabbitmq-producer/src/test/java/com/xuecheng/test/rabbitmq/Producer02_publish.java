package com.xuecheng.test.rabbitmq;

import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

//生产者发布订阅模式
public class Producer02_publish {
    private static final String QUEUE_INFORM_EMALL="queue_inform_cmail";
    private static final String QUEUE_INKORE_SMS="queue_inform_cms";
    private static final String EXCHORCE_FaKOUT_Ieform="exchange_fanout_inform";
    public static void main(String[] args) {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("127.0.0.1");
        connectionFactory.setPort(5672);
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        //设置虚拟机,一个MQ的服务可以设置多个虚拟机,而每个虚拟机就相当于独立的MQ
        connectionFactory.setVirtualHost("/");
        //和MQ建立连接
        Connection connection = null;
        Channel channel = null;
        try {
            connection = connectionFactory.newConnection();
            //创建会话通道,生产者和MQ所有的通信都是在Channel中完成
            channel = connection.createChannel();
            /*
             * 参数1 队列名称,参数2 是否持久话 ,参数3 是否独占连接,如果设置为true 可用于临时队列 exclusive
             * 参数4 autoDelete 自动删除
             * 参数5 qrgurents 参数,比如说存货时间
             * */
            channel.queueDeclare(QUEUE_INFORM_EMALL,true,false,false,null);
            channel.queueDeclare(QUEUE_INKORE_SMS,true,false,false,null);
            //声明一个交换机  参数1 exchange 交换机名称 参数2 type 交换机类型
            //交换机类型: fanout,对应rabbitmq的工作模式是 publish/subscribe
            //          direct ,对应Routing的工作模式
            //          topic, 对应Topics 工作模式
            //          headers, 对应headers 工作模式
            channel.exchangeDeclare(EXCHORCE_FaKOUT_Ieform, BuiltinExchangeType.FANOUT);
            //交换机和队列进行绑定
            //参数1,queue 队列名称 参数2 exchange交换机名 参数3 routingkey 在发布订阅模式中协调为空字符串
            channel.queueBind(QUEUE_INFORM_EMALL,EXCHORCE_FaKOUT_Ieform,"");
            channel.queueBind(QUEUE_INKORE_SMS,EXCHORCE_FaKOUT_Ieform,"");
            //发送消息
            /*
              1,exchange 交换机(使用默认的设置为空串) 2,routingkey 路由key 如果使用默认交换机,routingkey设置为队列的名称
              3,prosp,消息的属性  4,消息内容
            * */
            for (int i=0;i<5;i++){
                //定义一个消息内容
                String massge="send inform message to user";
                channel.basicPublish(EXCHORCE_FaKOUT_Ieform,"",null,massge.getBytes());
                System.out.println("send to sq"+massge);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭连接
            //先关闭通道
            try {
                channel.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (TimeoutException e) {
                e.printStackTrace();
            }
            try {
                connection.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}



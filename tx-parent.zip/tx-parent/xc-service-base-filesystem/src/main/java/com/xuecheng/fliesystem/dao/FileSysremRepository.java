package com.xuecheng.fliesystem.dao;

import com.xuecheng.framework.domain.filesystem.FileSystem;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FileSysremRepository extends MongoRepository<FileSystem,String> {
}

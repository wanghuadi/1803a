package com.xuecheng.framework.domain.cms.request;

import lombok.Data;

/*
  * wangyang
*/
@Data
public class QueryPageResult {
    //接收页面的查询条件

    //站点id
    private String siteId;
    //页面id
    private String pageId;
    //页面名称
    private String pageName;
   // 别名
    private String pageAliase;
    //模板
    private String templateId;

}

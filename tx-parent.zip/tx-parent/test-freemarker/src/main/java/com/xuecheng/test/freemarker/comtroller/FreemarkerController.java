package com.xuecheng.test.freemarker.comtroller;

import com.xuecheng.test.freemarker.model.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

@Controller
@RequestMapping("/freemarker")
public class FreemarkerController {

    @Autowired
    RestTemplate restTemplate;

    @RequestMapping("/banner")
    public  String index_banner(Map<String,Object> map){
        String dataUrl="http://localhost:31001/cms/config/getmodel/5a791725dd573c3574ee333f";
        ResponseEntity<Map> forEntity = restTemplate.getForEntity(dataUrl, Map.class);
        Map body = forEntity.getBody();
        //map.put("model",body);
        map.putAll(body);
        return "index_banner";
    }
    @RequestMapping("/course")
    public  String course(Map<String,Object> map){
        String dataUrl="http://localhost:31200/course/courseview/4028e581617f945f01617f9dabc40000";
        ResponseEntity<Map> forEntity = restTemplate.getForEntity(dataUrl, Map.class);
        Map body = forEntity.getBody();
        //map.put("model",body);
        map.putAll(body);
        return "course";
    }

    @RequestMapping("/test1")
    public  String test1(Map<String,Object> map){
        map.put("name","wangyang");
        Student s1 = new Student();
        s1.setName("小明");
        s1.setAge(18);
        s1.setMoney(1000.86f);
        s1.setBirthday(new Date());
        Student s2 = new Student();
        s2.setName("123");
        s2.setAge(182);
        s2.setMoney(10004.86f);
        s2.setBirthday(new Date());
        ArrayList<Student> ss = new ArrayList<>();
        ss.add(s1);
        ss.add(s2);
        map.put("ss",ss);

        return "test1";
    }
}

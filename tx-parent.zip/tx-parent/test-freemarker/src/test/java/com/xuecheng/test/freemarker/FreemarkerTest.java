package com.xuecheng.test.freemarker;

import com.xuecheng.test.freemarker.model.Student;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@SpringBootTest
@RunWith(SpringRunner.class)
public class FreemarkerTest {

    @Test
    public void testGenerateHtml() throws IOException, TemplateException {
        Configuration configuration = new Configuration(Configuration.getVersion());
        String classPath = this.getClass().getResource("/").getPath();
        configuration.setDirectoryForTemplateLoading(new File(classPath + "/templates/"));
        Template template = configuration.getTemplate("test1.ftl");
        Map map = get();
        String s = FreeMarkerTemplateUtils.processTemplateIntoString(template, map);
        InputStream inputStream = IOUtils.toInputStream(s);
        FileOutputStream fileOutputStream = new FileOutputStream(new File("C:/Users/王洋/Desktop//html/test1.html"));
        IOUtils.copy(inputStream, fileOutputStream);
        inputStream.close();
        fileOutputStream.close();
    }
     //基于模板文件的内容生成html
    @Test
    public void testGenerateHtmlByString() throws IOException, TemplateException {
        Configuration configuration = new Configuration(Configuration.getVersion());
        String templateString = "" + "<html>\n" + " <head></head>\n" + " <body>\n" + " 名称：${name}\n" + " </body>\n" + "</html>";
        StringTemplateLoader stringTemplateLoader = new StringTemplateLoader();
        stringTemplateLoader.putTemplate("template",templateString);
        configuration.setTemplateLoader(stringTemplateLoader);
        Template template = configuration.getTemplate("template", "utf-8");
        Map map = get();
        String s = FreeMarkerTemplateUtils.processTemplateIntoString(template, map);
        InputStream inputStream = IOUtils.toInputStream(s);
        FileOutputStream fileOutputStream = new FileOutputStream(new File("C:/Users/王洋/Desktop//html/test2.html"));
        IOUtils.copy(inputStream, fileOutputStream);
        inputStream.close();
        fileOutputStream.close();



    }

    public Map get() {
        HashMap<String, Object> map = new HashMap<>();
        map.put("name", "wangyang");
        Student s1 = new Student();
        s1.setName("小明");
        s1.setAge(18);
        s1.setMoney(1000.86f);
        s1.setBirthday(new Date());
        Student s2 = new Student();
        s2.setName("123");
        s2.setAge(182);
        s2.setMoney(10004.86f);
        s2.setBirthday(new Date());
        ArrayList<Student> ss = new ArrayList<>();
        ss.add(s1);
        ss.add(s2);
        map.put("ss", ss);
        return map;
    }
}

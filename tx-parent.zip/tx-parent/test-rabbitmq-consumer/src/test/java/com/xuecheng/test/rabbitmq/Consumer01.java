package com.xuecheng.test.rabbitmq;

import com.rabbitmq.client.*;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

//消费者
public class Consumer01 {
    private static final String QUEUE="Helloword";
    public static void main(String[] args) throws IOException, TimeoutException {
        //连接工程
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("127.0.0.1");
        connectionFactory.setPort(5672);
        connectionFactory.setUsername("guest");
        connectionFactory.setPassword("guest");
        //设置虚拟机,一个MQ的服务可以设置多个虚拟机,而每个虚拟机就相当于独立的MQ
        connectionFactory.setVirtualHost("/");
        //和MQ建立连接
        Connection connection = null;

            connection = connectionFactory.newConnection();
            //创建会话通道,生产者和MQ所有的通信都是在Channel中完成
            Channel channel = connection.createChannel();
            //监听队列 去声明队列
            /*
             * 参数1 队列名称,参数2 是否持久话 ,参数3 是否独占连接,如果设置为true 可用于临时队列 exclusive
             * 参数4 autoDelete 自动删除
             * 参数5 qrgurents 参数,比如说存货时间
             * */
            channel.queueDeclare(QUEUE,true,false,false,null);
            //消费方法
            DefaultConsumer defaultConsumer = new DefaultConsumer(channel){
                /**
                 *当接受到消息后,此方法将被调用
                 * @param consumerTag  消费者标签,用来表示消费者的,在监听队列时设置 channel.basicConsumc
                 * @param envelope     信封,通过
                 * @param properties   消息属性
                 * @param body         消息内容
                 * @throws IOException
                 */
                @Override
                public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                    super.handleDelivery(consumerTag, envelope, properties, body);
                    String exchange = envelope.getExchange();//交换机
                    long deliveryTag = envelope.getDeliveryTag();//消息的ID,mq在channel中表示消息的Id,可用于确认消息已接收
                    String message= new String(body,"utf-8");
                    System.out.println("recelve message"+message);
                }
            };
            //监听队列
            //参数明细
            //1,queue队列名称 2,autoAck 自动回复,设置为true 表示自动回复,设置为false 通过编程实现回复
            //3,callback 消费方法,当消费者接收到消息要执行的方法
            channel.basicConsume(QUEUE,true,defaultConsumer);


    }
}

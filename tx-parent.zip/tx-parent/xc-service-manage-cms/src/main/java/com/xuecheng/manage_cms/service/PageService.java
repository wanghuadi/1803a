package com.xuecheng.manage_cms.service;

import com.alibaba.fastjson.JSON;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSDownloadStream;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.xuecheng.framework.domain.cms.CmsConfig;
import com.xuecheng.framework.domain.cms.CmsPage;
import com.xuecheng.framework.domain.cms.CmsSite;
import com.xuecheng.framework.domain.cms.CmsTemplate;
import com.xuecheng.framework.domain.cms.request.QueryPageResult;
import com.xuecheng.framework.domain.cms.response.CmsCode;
import com.xuecheng.framework.domain.cms.response.CmsPageResult;
import com.xuecheng.framework.domain.cms.response.CmsPostPageResult;
import com.xuecheng.framework.exception.ExceptionCast;
import com.xuecheng.framework.model.response.CommonCode;
import com.xuecheng.framework.model.response.QueryResponseResult;
import com.xuecheng.framework.model.response.QueryResult;
import com.xuecheng.framework.model.response.ResponseResult;
import com.xuecheng.manage_cms.config.RabbitmgConfig;
import com.xuecheng.manage_cms.dao.CmsConfigRepository;
import com.xuecheng.manage_cms.dao.CmsPageRepository;
import com.xuecheng.manage_cms.dao.CmsSiteRepository;
import com.xuecheng.manage_cms.dao.CmsTemplateRepository;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class PageService {
    @Autowired
    CmsPageRepository CmsPageRepository;

    @Autowired
    CmsConfigRepository CmsConfigRepository;

    @Autowired
    CmsTemplateRepository CmsTemplateRepository;

    @Autowired
    RestTemplate RestTemplate;
    @Autowired
    GridFsTemplate GridFsTemplate;
    @Autowired
    GridFSBucket GridFSBucket;

    @Autowired
    RabbitTemplate rabbitTemplate;

    @Autowired
    CmsSiteRepository CmsSiteRepository;

    public QueryResponseResult findList(int page, int size, QueryPageResult QueryPageResult) {
        //实现自定义查询
        //定义条件匹配器
        if (QueryPageResult == null) {
            QueryPageResult = new QueryPageResult();
        }
        ExampleMatcher matching = ExampleMatcher.matching().withMatcher("pageAliase", ExampleMatcher.GenericPropertyMatchers.contains());
        CmsPage cmsPage = new CmsPage();
        String siteId = QueryPageResult.getSiteId();
        if (StringUtils.isNotEmpty(siteId)) {
            cmsPage.setSiteId(siteId);
        }
        String templateId = QueryPageResult.getTemplateId();
        if (StringUtils.isNotEmpty(templateId)) {
            cmsPage.setTemplateId(templateId);
        }
        String pageAliase = QueryPageResult.getPageAliase();
        if (StringUtils.isNotEmpty(pageAliase)) {
            cmsPage.setPageAliase(pageAliase);
        }
        Example<CmsPage> example = Example.of(cmsPage, matching);
        if (page <= 0) {
            page = 1;
        }
        page = page - 1;
        if (size <= 0) {
            size = 10;
        }
        Pageable pageable = PageRequest.of(page, size);
        Page<CmsPage> all = CmsPageRepository.findAll(example, pageable);
        QueryResult QueryResult = new QueryResult();
        QueryResult.setList(all.getContent());
        QueryResult.setTotal(all.getTotalElements());
        QueryResponseResult queryResponseResult = new QueryResponseResult(CommonCode.SUCCESS, QueryResult);
        return queryResponseResult;
    }
    //新增
    public CmsPageResult add(CmsPage cmsPage) {
        if (cmsPage == null) {
              //抛出异常
            ExceptionCast.cast(CommonCode.FAIL);
        }
        //页面名称,站点ID,页面webpath去查询,是为了保证页面的唯一性
        CmsPage cmspage = CmsPageRepository.findByPageNameAndSiteIdAndPageWebPath(cmsPage.getPageName(), cmsPage.getSiteId(), cmsPage.getPageWebPath());
        if (cmspage != null) {
             //抛出异常
            ExceptionCast.cast(CmsCode.CMS_ADDPAGE_EXISTSNAME);
        }
        cmsPage.setPageId(null);//为了防止手动添加主键,因为Mongodb的主键是自增的
        CmsPage save = CmsPageRepository.save(cmsPage);
        return new CmsPageResult(CommonCode.SUCCESS, save);
    }
    //根据ID查询页面
    public CmsPage getById(String id) {
        Optional<CmsPage> optional = CmsPageRepository.findById(id);
        if (optional.isPresent()) {
            CmsPage cmsPage = optional.get();
            return cmsPage;
        } else {
            return null;
        }
    }
    //修改
    public CmsPageResult update(String id, CmsPage CmsPage) {
        CmsPage cms = this.getById(id);
        if (cms != null) {
            cms.setTemplateId(CmsPage.getTemplateId());
            cms.setSiteId(CmsPage.getSiteId());
            cms.setPageAliase(CmsPage.getPageAliase());
            cms.setPageName(CmsPage.getPageName());
            cms.setPageWebPath(CmsPage.getPageWebPath());
            cms.setPagePhysicalPath(CmsPage.getPagePhysicalPath());
            cms.setDataUrl(CmsPage.getDataUrl());

            CmsPageRepository.save(cms);
            return new CmsPageResult(CommonCode.SUCCESS, cms);
        }
        return new CmsPageResult(CommonCode.FAIL, null);
    }
    //根据ID删除
    public ResponseResult delete(String id) {
        Optional<CmsPage> optional = CmsPageRepository.findById(id);
        if (optional != null) {
            CmsPageRepository.deleteById(id);
            return new ResponseResult(CommonCode.SUCCESS);
        }
        return new ResponseResult(CommonCode.FAIL);
    }
    //根据ID查询cmsConfig
    public CmsConfig getConfigById(String id){
        Optional<CmsConfig> byId = CmsConfigRepository.findById(id);
        if(byId.isPresent()){
            CmsConfig cmsConfig = byId.get();
            return cmsConfig;
        }
        return null;
    }
    //页面静态化方法
    /**
     * 静态化程序获取页面的DataUrl
     *
     * 静态化程序远程请求DataUrl获取数据模型。
     *
     * 静态化程序获取页面的模板信息
     *
     * 执行页面静态化
     */
    public String getPageHtml(String pageId){

        //获取数据模型
        Map model = getModelByPageId(pageId);
        if(model == null){
            //数据模型获取不到
            ExceptionCast.cast(CmsCode.CMS_GENERATEHTML_DATAISNULL);
        }

        //获取页面的模板信息
        String template = getTemplateByPageId(pageId);
        if(StringUtils.isEmpty(template)){
            ExceptionCast.cast(CmsCode.CMS_GENERATEHTML_TEMPLATEISNULL);
        }

        //执行静态化
        String html = generateHtml(template, model);
        return html;

    }
    //执行静态化
    private String generateHtml(String templateContent,Map model ){
        //创建配置对象
        Configuration configuration = new Configuration(Configuration.getVersion());
        //创建模板加载器
        StringTemplateLoader stringTemplateLoader = new StringTemplateLoader();
        stringTemplateLoader.putTemplate("template",templateContent);
        //向configuration配置模板加载器
        configuration.setTemplateLoader(stringTemplateLoader);
        //获取模板
        try {
            Template template = configuration.getTemplate("template");
            //调用api进行静态化
            String content = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
            return content;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    //获取页面的模板信息
    private String getTemplateByPageId(String pageId){
        //取出页面的信息
        CmsPage cmsPage = this.getById(pageId);
        if(cmsPage == null){
            //页面不存在
            ExceptionCast.cast(CmsCode.CMS_PAGE_NOTEXISTS);
        }
        //获取页面的模板id
        String templateId = cmsPage.getTemplateId();
        if(StringUtils.isEmpty(templateId)){
            ExceptionCast.cast(CmsCode.CMS_GENERATEHTML_TEMPLATEISNULL);
        }
        //查询模板信息
        Optional<CmsTemplate> optional = CmsTemplateRepository.findById(templateId);
        if(optional.isPresent()){
            CmsTemplate cmsTemplate = optional.get();
            //获取模板文件id
            String templateFileId = cmsTemplate.getTemplateFileId();
            //从GridFS中取模板文件内容
            //根据文件id查询文件
            GridFSFile gridFSFile = GridFsTemplate.findOne(Query.query(Criteria.where("_id").is(templateFileId)));

            //打开一个下载流对象
            GridFSDownloadStream gridFSDownloadStream = GridFSBucket.openDownloadStream(gridFSFile.getObjectId());
            //创建GridFsResource对象，获取流
            GridFsResource gridFsResource = new GridFsResource(gridFSFile,gridFSDownloadStream);
            //从流中取数据
            try {
                String content = IOUtils.toString(gridFsResource.getInputStream(), "utf-8");
                return content;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;

    }

    //获取数据模型
    private Map getModelByPageId(String pageId){
        //取出页面的信息
        CmsPage cmsPage = this.getById(pageId);
        if(cmsPage == null){
            //页面不存在
            ExceptionCast.cast(CmsCode.CMS_PAGE_NOTEXISTS);
        }
        //取出页面的dataUrl
        String dataUrl = cmsPage.getDataUrl();
        if(StringUtils.isEmpty(dataUrl)){
            //页面dataUrl为空
            ExceptionCast.cast(CmsCode.CMS_GENERATEHTML_DATAURLISNULL);
        }
        //通过restTemplate请求dataUrl获取数据,   RestTemplate简化了与http服务的通信，程序代码可以给它提供URL，并提取结果
        ResponseEntity<Map> forEntity = RestTemplate.getForEntity(dataUrl, Map.class);
        Map body = forEntity.getBody();
        return body;
    }
    //页面发布
    public  ResponseResult post(String pageId){
        //执行页面静态化
        String pageHtml = this.getPageHtml(pageId);
        //将页面静态化文件存储到GridFS中
        CmsPage cmsPage = saveHtml(pageId, pageHtml);
        //向MQ发消息
        sendPOstPage(pageId);
        return new ResponseResult(CommonCode.SUCCESS);
    }
    //向mq发送消息
    private void   sendPOstPage(String pageId){
        //得到页面信息
        CmsPage cmsPage = this.getById(pageId);
        if(cmsPage == null){
            ExceptionCast.cast(CommonCode.INVALID_PARAM);
        }
        //创建消息对象
         Map<String,String> map = new HashMap<>();
         map.put("pageId",pageId);
         //转成json串
        String jsonString = JSON.toJSONString(map);
        //站点ID
        String siteId = cmsPage.getSiteId();
        //发送mq
        rabbitTemplate.convertAndSend(RabbitmgConfig.EX_ROUTING_CMS_POSTPAGE,siteId,jsonString);
    }
    //保存存Html到GridFS
    private CmsPage saveHtml(String pageId,String  htmlContent){
        //得到页面的信息
        CmsPage cmsPage = this.getById(pageId);
        if(cmsPage == null){
            ExceptionCast.cast(CommonCode.INVALID_PARAM);
        }
        ObjectId objectId = null;
        try {
            //将htmlContent内容转成输入流
            InputStream inputStream = IOUtils.toInputStream(htmlContent, "utf-8");
            //将html文件内容保存到GridFS
            objectId  = GridFsTemplate.store(inputStream, cmsPage.getPageName());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //将html文件id更新到cmsPage中
        cmsPage.setHtmlFileId(objectId.toHexString());
        CmsPageRepository.save(cmsPage);
        return cmsPage;
    }
    //保存页面,有则更新,没有则添加
    public CmsPageResult saveCmsPage(CmsPage cmsPage) {
        //判断页面是否存在
        CmsPage cms = CmsPageRepository.findByPageNameAndSiteIdAndPageWebPath(cmsPage.getPageName(), cmsPage.getSiteId(), cmsPage.getPageWebPath());
        if(cms!=null){
            //进行更新
          return  this.update(cms.getPageId(),cmsPage);
        }
        //进行添加
        return this.add(cmsPage);
    }
    //一键发布页面
    public CmsPostPageResult postPageQuick(CmsPage cmsPage) {
        //将页面信息存储到cms_page集合中
        //调用发布方法
        CmsPageResult save = this.saveCmsPage(cmsPage);
        if(!save.isSuccess()){
            ExceptionCast.cast(CommonCode.FAIL);
        }
        //得到页面的Id
        CmsPage cmsPageSave = save.getCmsPage();
        String pageId = save.getCmsPage().getPageId();
        //执行页面发布(先静态化,保存到GridFS,向MQ发送消息)
        ResponseResult post = this.post(pageId);
        if(!post.isSuccess()){
            ExceptionCast.cast(CommonCode.FAIL);
        }
        //拼装页面 URL
        //取出站点ID
        String siteId = cmsPageSave.getSiteId();
        //得到站点信息
        CmsSite cmsSite = this.findCmsSiteById(siteId);
        //页面URl
        String pageUrl =cmsSite.getSiteDomain() +cmsSite.getSiteWebPath()+cmsPageSave.getPageWebPath()+cmsPageSave.getPageName();
        return new CmsPostPageResult(CommonCode.SUCCESS,pageUrl);
    }
    //根据站点ID查询站点信息
    private CmsSite findCmsSiteById(String siteId){
        Optional<CmsSite> optional = CmsSiteRepository.findById(siteId);
        if(optional.isPresent()){
            return optional.get();
        }
        return null;
    }
}

package com.xuecheng.manage_cms.controller;

import com.xuecheng.api.cms.CmsTemplateControlleApi;
import com.xuecheng.framework.domain.cms.CmsTemplate;
import com.xuecheng.manage_cms.service.CmsTemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/cms/template")
public class CmsTemplateController implements CmsTemplateControlleApi {
    @Autowired
    CmsTemplateService CmsTemplateService;
    @Override
    @GetMapping("/findAll")
    public List<CmsTemplate> findAll() {
        return CmsTemplateService.findAll();
    }
}

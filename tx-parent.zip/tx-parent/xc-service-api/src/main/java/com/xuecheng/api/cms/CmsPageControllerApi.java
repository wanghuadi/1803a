package com.xuecheng.api.cms;

import com.xuecheng.framework.domain.cms.CmsPage;
import com.xuecheng.framework.domain.cms.request.QueryPageResult;
import com.xuecheng.framework.domain.cms.response.CmsPageResult;
import com.xuecheng.framework.domain.cms.response.CmsPostPageResult;
import com.xuecheng.framework.model.response.QueryResponseResult;
import com.xuecheng.framework.model.response.ResponseResult;
import io.swagger.annotations.ApiOperation;

public interface CmsPageControllerApi {
    //页面查询
    public QueryResponseResult findList(int page, int size, QueryPageResult QueryPageResult);

    //添加页面
    @ApiOperation("新增接口")
    public CmsPageResult add(CmsPage cmsPage);

    //根据ID查询页面
    @ApiOperation("根据ID查询页面接口")
     public CmsPage findById(String id);
    //修改页面
    @ApiOperation("修改页面接口")
    public CmsPageResult update(String id,CmsPage CmsPage);

    @ApiOperation("删除")
    public ResponseResult delete(String id);

    //页面发布
    public ResponseResult post(String pageId);

    //保存页面
    @ApiOperation("保存页面")
    public CmsPageResult save(CmsPage cmsPage);
    @ApiOperation(("一键发布页面"))
    public CmsPostPageResult postPageQuick(CmsPage cmsPage);
}

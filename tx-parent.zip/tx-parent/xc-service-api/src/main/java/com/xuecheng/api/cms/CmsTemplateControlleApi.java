package com.xuecheng.api.cms;

import com.xuecheng.framework.domain.cms.CmsTemplate;

import java.util.List;

public interface CmsTemplateControlleApi {

    public List<CmsTemplate> findAll();
}

package com.xuecheng.api.cms;

import com.xuecheng.framework.domain.cms.CmsSite;

import java.util.List;

public interface CmsSiteControllerApi {

    public List<CmsSite> findAll();
}

package com.xuecheng.framework.model.response;

/**
 * Created by admin on 2018/3/5.
 */
public interface Response {
    public static final boolean SUCCESS = true;
    public static final int SUCCESS_CODE = 10000;
}

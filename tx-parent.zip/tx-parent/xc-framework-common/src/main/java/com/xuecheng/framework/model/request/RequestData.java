package com.xuecheng.framework.model.request;

import lombok.Data;
import lombok.ToString;

/**
 * Created by mrt on 2018/3/5.
 */
@Data
@ToString
public class RequestData {
}
